sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("customer.fioriapp.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
